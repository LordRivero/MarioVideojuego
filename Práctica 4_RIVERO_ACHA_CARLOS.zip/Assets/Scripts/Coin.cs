using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coin : MonoBehaviour
{
    public int Value = 1; //Valor de la moneda.
    private int coinTotal;
    public AudioClip coinClip;
    private void OnTriggerEnter2D(Collider2D collision) //M�todo para detectar cuando el jugador entra en contacto con la moneda.
    {
        if (collision.gameObject.GetComponent<PlayerMovement>())//Comprueba si el objeto que colisiona es el jugador.
        {
            coinTotal = GameManager.instance.GetPoints();
            coinTotal = Value + coinTotal;
            GameManager.instance.SetPoints(coinTotal);
            AudioManager.instance.PlayAudio(coinClip, "CoinSound", false, 0.1f);
            Destroy(this.gameObject);
        }
    }
}


