using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreManager : MonoBehaviour
{
    public Text scoreText;
    public Text timeText;

    private float timer = 0f;
    private int score = 0;

    private void Update() //Actualizar el tiempo transcurrido.
    {
        timer += Time.deltaTime;
        timeText.text = "Tiempo" + timer.ToString();

        scoreText.text = "Puntuaci�n" + score.ToString();
    }
}
