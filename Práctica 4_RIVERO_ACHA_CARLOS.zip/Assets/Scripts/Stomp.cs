using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stomp : MonoBehaviour
{
    public int value = 10;
    private int coinTotal;

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "Weak Point")
        {
            coinTotal = GameManager.instance.GetPoints();
            coinTotal = coinTotal + value;
            GameManager.instance.SetPoints(coinTotal);
            Destroy(collision.gameObject);
        }
    }
}
