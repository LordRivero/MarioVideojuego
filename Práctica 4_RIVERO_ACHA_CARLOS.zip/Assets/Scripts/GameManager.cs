using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;

    public enum GameManagerVariables { TIME, POINTS }; //Declara una estructura tipo enum (enumerar) para faciliar la lectura del c�digo. time seria 0, points 1.

    private float time;
    private int points;

    private void Awake()
    {
        //SINGLETON
        if (!instance) //SI INSTANCE NO TIENE INFORMACION.
        {
            instance = this; //instance se asigna a este objeto
            DontDestroyOnLoad(gameObject); //se indica que el objeto no se destruya con la carga de escenas.
        }
        else //si instance tiene info
        {
            Destroy(gameObject); //se destruye el GameObject, para que no haya dos o m�s GameObjects en el juegO.
        }
    }

    void Start()
    {
        
    }

    void Update()
    {
        time += Time.deltaTime;
    }

    public float GetTime()
    {
        return time;
    }

    public int GetPoints()
    {
        return points;
    }
    //setter
    public void SetPoints(int value)
    {
        points = value;
    }
    //callback: funcion que va a llamar en el onclick() de los botones.
    public void LoadScene(string sceneName)
    {
        SceneManager.LoadScene(sceneName);
        //oye, audioManager, limpia todos los sonidos que est�n sonando.
        AudioManager.instance.ClearAudios();
    }

    public void ExitGame()
    {
        Debug.Log("Exit!!");
        Application.Quit();
    }
}
