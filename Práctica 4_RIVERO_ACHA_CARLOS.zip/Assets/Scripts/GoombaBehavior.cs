using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class GoombaBehavior : MonoBehaviour
{
    public GameObject target;
    public float speed;
    public SpriteRenderer _rend;

    private void Start()
    {
        _rend = GetComponent<SpriteRenderer>();
        target = FindObjectOfType<PlayerMovement>().gameObject;
    }

    // Update is called once per frame
    void Update()
    {
       if (target != null)
        {
            if (transform.position.x < target.transform.position.x) //El enemigo sigue a nuestro personaje si se posiciona a la derecha
            {
                transform.Translate(Vector2.right * speed * Time.deltaTime);
                _rend.flipX = false;
            }
            else if (transform.position.x > target.transform.position.x)  //El enemigo sigue a nuestro personaje si se posiciona a la izquierda
            {
                transform.Translate(Vector2.left * speed * Time.deltaTime);
                _rend.flipX = true;
            }
        }  
        //transform.position = 
            //Vector2.MoveTowards(transform.position, new Vector2(target.transform.position.x, transform.position.y), speed * Time.deltaTime);   
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.GetComponent<PlayerMovement>())
        {
            //Destroy(collision.gameObject);
            collision.gameObject.GetComponent<PlayerMovement>().ResetPlayer();
        }

    }

    public void StartDeath()
    {
        GetComponent<Animator>().Play("Death");
    }

    public void DestroyGoomba()
    {
        Destroy(gameObject);
    }
}